
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class ReservasHotel {

    private static Hotel hotel;

    private static Scanner lectura = new Scanner(System.in);
    private static String valorEscrito = "";
    private static String tipoHabitacion;

    private static List<Habitacion> listHabitacionHotel = new ArrayList<>();

    private static List<Habitacion> listHabitacionDisponibles;

    private static Habitacion habitacion;

    private static List<Reserva> listReservas = new ArrayList<>();

    private static Clientes cliente;

    public static void main(String[] args) {
        try {
            CrearHabitacionesHotel();

            hotel.MostrarHotel();

            System.out.println("");
            System.out.println("*** BIENVENIDOS A SU SISTEMA DE RESERVA***");

            IngresarCliente();

            PedirHabitacion();

        } catch (Exception ex) {
            System.out.println("ha ocurrido un error: " + ex.getMessage());
            System.out.println("ha ocurrido un error: " + ex.toString());
        }
    }

    private static void CrearHabitacionesHotel() {
        Habitacion habitaciones;
        List<Habitacion> listHabitacion = new ArrayList<>();
        try {

            //3 sencillas
            habitaciones = new Habitacion(1001, "Habitacion 1001", "Sencilla", "wc,tv,cama sencilla", 1, 60000);
            listHabitacion.add(habitaciones);

            habitaciones = new Habitacion(1002, "Habitacion 1002", "Sencilla", "wc,tv,cama sencilla", 1, 60000);
            listHabitacion.add(habitaciones);

            habitaciones = new Habitacion(1003, "Habitacion 1003", "Sencilla", "wc,tv,cama sencilla", 1, 60000);
            listHabitacion.add(habitaciones);

            //3 dobles
            habitaciones = new Habitacion(1004, "Habitacion 1004", "Doble", "wc,tv,cama doble", 2, 80000);
            listHabitacion.add(habitaciones);

            habitaciones = new Habitacion(1005, "Habitacion 1005", "Doble", "wc,tv,cama doble", 2, 80000);
            listHabitacion.add(habitaciones);

            habitaciones = new Habitacion(1006, "Habitacion 1006", "Doble", "wc,tv,cama doble", 2, 80000);
            listHabitacion.add(habitaciones);

            //3 semi doble
            habitaciones = new Habitacion(1007, "Habitacion 1007", "Semi Doble", "wc,tv,cama sencilla y doble", 3, 100000);
            listHabitacion.add(habitaciones);

            habitaciones = new Habitacion(1008, "Habitacion 1008", "Semi Doble", "wc,tv,cama sencilla y doble", 3, 100000);
            listHabitacion.add(habitaciones);

            habitaciones = new Habitacion(1009, "Habitacion 1009", "Semi Doble", "wc,tv,cama sencilla y doble", 3, 100000);
            listHabitacion.add(habitaciones);

            //3 grandes
            habitaciones = new Habitacion(1010, "Habitacion 1010", "Grande", "wc,tv,2 cama doble", 4, 120000);
            listHabitacion.add(habitaciones);

            habitaciones = new Habitacion(1011, "Habitacion 1011", "Grande", "wc,tv,2 cama doble", 4, 120000);
            listHabitacion.add(habitaciones);

            habitaciones = new Habitacion(1012, "Habitacion 1012", "Grande", "wc,tv,2 cama doble", 4, 120000);
            listHabitacion.add(habitaciones);

            CrearHotel(listHabitacion);

        } catch (Exception ex) {
            System.out.println("ha ocurrido un error: " + ex.getMessage());
            System.out.println("ha ocurrido un error: " + ex.toString());
        }
    }

    private static void CrearHotel(List<Habitacion> listHabitacion) {
        try {
            hotel = new Hotel(1000, "Hotel JB", "5 Estrellas", "Calle 20 # 23-70", "3013641465", listHabitacion);
        } catch (Exception ex) {
            System.out.println("ha ocurrido un error: " + ex.getMessage());
            System.out.println("ha ocurrido un error: " + ex.toString());
        }
    }

    private static void PedirHabitacion() {

        String terminar = "";
        Reserva reserva;

        try {

            lectura = new Scanner(System.in);
            do {

                System.out.println("Ingrese tipo habitacion a buscar([1]Sencilla, [2]Doble(2), [3]SemiDoble, [4]Grande)::");
                valorEscrito = lectura.next();
                valorEscrito = valorEscrito.trim();

                if (validarEntrada("TipoHabitacion", valorEscrito) == false) {
                    terminar = "SI";
                    System.out.println("Entrada Errada, debe escribir: 1,2,3 0 4");
                    break;
                }

                listHabitacionHotel = hotel.getHabitaciones();

                listHabitacionDisponibles = new ArrayList<>();

                for (Habitacion hab : listHabitacionHotel) {

                    if (tipoHabitacion.equals(hab.getTipo())) {

                        if (BuscarReservaHabitacion(hab)) {
                            System.out.println(">>> ESTA HABITACION SE ENCUENTRA RESERVADA");
                            hab.MostrarHabitacion();
                        } else {
                            System.out.println(">>> ESTA HABITACION SE ENCUENTRA DISPONIBLE");
                            hab.MostrarHabitacion();

                            listHabitacionDisponibles.add(hab);
                        }

                    }

                }

                if (listHabitacionDisponibles.isEmpty()) {
                    System.out.println("");
                    System.out.println("*** NO HAY DISPOBIBILIDAD PARA EL TIPO DE HABITACION BUSCADA ***");
                } else {

                    valorEscrito = "NA";

                    do {

                        System.out.println("Desea Reservar Habitacion?...Escriba: (SI o NO)::");
                        valorEscrito = lectura.next();
                        valorEscrito = valorEscrito.trim();
                        valorEscrito = valorEscrito.toUpperCase();

                        if (validarEntrada("Reservar", valorEscrito) == false) {
                            System.out.println("Entrada Errada, debe escribir: SI o NO");
                            valorEscrito = "NA";
                        }

                    } while ("NA".equals(valorEscrito));

                    habitacion = listHabitacionDisponibles.get(0);

                    if ("SI".equals(valorEscrito)) {

                        int codReserva;
                        codReserva = new Random().nextInt(1, 100);

                        reserva = new Reserva(codReserva, habitacion.getPrecio(), habitacion.getCapacidadPersonas(), habitacion, cliente);
                        listReservas.add(reserva);

                        System.out.println("Ok Reserva realizada");
                        reserva.MostrarReserva();

                    } else {
                        System.out.println("No realiza reserva");
                    }
                }

                System.out.println("Desea Terminar, escriba (SI), de lo contrario debe continuar::");
                valorEscrito = lectura.next();
                valorEscrito = valorEscrito.trim();
                terminar = valorEscrito.toUpperCase();

            } while (!"SI".equals(terminar));

            System.out.println("*** Fin ***");

        } catch (Exception ex) {
            System.out.println("ha ocurrido un error: " + ex.getMessage());
            System.out.println("ha ocurrido un error: " + ex.toString());
        }
    }

    private static boolean BuscarReservaHabitacion(Habitacion habitacion) {
        int codigoHabitacion;
        int codHbitacionReser;
        Habitacion hab;
        boolean existe = false;

        try {

            codigoHabitacion = habitacion.getCodigo();

            for (Reserva reserva : listReservas) {
                hab = reserva.getHabitacion();
                codHbitacionReser = hab.getCodigo();

                if (codigoHabitacion == codHbitacionReser) {
                    existe = true;
                    return existe;
                }
            }

        } catch (Exception ex) {
            System.out.println("ha ocurrido un error: " + ex.getMessage());
            System.out.println("ha ocurrido un error: " + ex.toString());
            existe = false;
        }
        return existe;
    }

    private static boolean validarEntrada(String entrada, String valor) {
        boolean result = false;
        try {

            if ("TipoHabitacion".equals(entrada)) {
                switch (valor.toUpperCase()) {
                    case "1":
                        result = true;
                        tipoHabitacion = "Sencilla";
                        break;
                    case "2":
                        result = true;
                        tipoHabitacion = "Doble";
                        break;
                    case "3":
                        result = true;
                        tipoHabitacion = "Semi Doble";
                        break;
                    case "4":
                        result = true;
                        tipoHabitacion = "Grande";
                        break;
                    default:
                        result = false;
                        break;
                }
            }

            if ("Reservar".equals(entrada)) {
                switch (valor.toUpperCase()) {
                    case "SI":
                        result = true;
                        break;
                    case "NO":
                        result = true;
                        break;
                    default:
                        result = false;
                        break;
                }
            }

            return result;

        } catch (Exception ex) {
            System.out.println("ha ocurrido un error: " + ex.getMessage());
            return false;
        }
    }

    private static void IngresarCliente() {
        long identificacion;
        String nombres = "";
        String movil;
        try {
            System.out.println("*** Ingresar Cliente***");

            try {
                System.out.println("Ingrese Numero Identificacion::");
                identificacion = lectura.nextLong();
            } catch (Exception e) {
                System.out.println("ha ocurrido un error: " + e.toString());
                identificacion = 0;
            }

            lectura = new Scanner(System.in);
            System.out.println("Ingrese Nombres y Apellidos::");
            valorEscrito = lectura.nextLine();
            valorEscrito = valorEscrito.trim();
            nombres = valorEscrito.toUpperCase();

            lectura = new Scanner(System.in);
            System.out.println("Ingrese Celular::");
            valorEscrito = lectura.next();
            valorEscrito = valorEscrito.trim();
            movil = valorEscrito;

            cliente = new Clientes(identificacion, nombres, movil);

        } catch (Exception ex) {
            System.out.println("ha ocurrido un error: " + ex.getMessage());
            System.out.println("ha ocurrido un error: " + ex.toString());
        }
    }
}
