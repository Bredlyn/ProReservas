
public class Reserva {

    private int codigo;
    private float precioTotal;
    private int numerOcupantes;
    private Clientes cliente;
    private Habitacion habitacion;

    public Reserva() {
    }

    public Reserva(int codigo, float precioTotal, int numerOcupantes, Habitacion habitacion, Clientes cliente) {
        this.codigo = codigo;
        this.precioTotal = precioTotal;
        this.numerOcupantes = numerOcupantes;
        this.habitacion = habitacion;
        this.cliente = cliente;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public float getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(float precioTotal) {
        this.precioTotal = precioTotal;
    }

    public int getNumerOcupantes() {
        return numerOcupantes;
    }

    public void setNumerOcupantes(int numerOcupantes) {
        this.numerOcupantes = numerOcupantes;
    }

    public Clientes getCliente() {
        return cliente;
    }

    public void setCliente(Clientes cliente) {
        this.cliente = cliente;
    }

    public Habitacion getHabitacion() {
        return habitacion;
    }

    public void setHabitacion(Habitacion habitacion) {
        this.habitacion = habitacion;
    }

    public void MostrarReserva() {
        try {
            System.out.println("***Su Reserva..Confirmacion***");
            System.out.println("Codigo: [" + this.codigo + "] "
                    + "Precio: [" + this.precioTotal + "] "
                    + "Ocupantes: [" + this.numerOcupantes + "]");

            System.out.println("***Habitacion Reservada***");
            this.habitacion.MostrarHabitacion();

            System.out.println("***Cliente Reserva***");
            this.cliente.MostrarCliente();

        } catch (Exception ex) {
            System.out.println("ha ocurrido un error: " + ex.getMessage());
        }
    }

}
