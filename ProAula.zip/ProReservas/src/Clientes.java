
public class Clientes {

    private long identificacion;
    private String nombresCompletos;
    private String movil;

    public Clientes() {
    }

    public Clientes(long identificacion, String nombresCompletos, String movil) {
        this.identificacion = identificacion;
        this.nombresCompletos = nombresCompletos;
        this.movil = movil;
    }
 
    public long getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(long identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombresCompletos() {
        return nombresCompletos;
    }

    public void setNombresCompletos(String nombres) {
        this.nombresCompletos = nombres;
    }

    public String getMovil() {
        return movil;
    }

    public void setMovil(String movil) {
        this.movil = movil;
    }

    public void MostrarCliente() {
        try {
            System.out.println("[...Identificacion: [" + this.identificacion + "] "
                    + "Nombres: [" + this.nombresCompletos + "] "
                    + "Telefono: [" + this.movil + "]...]");
        } catch (Exception ex) {
            System.out.println("ha ocurrido un error: " + ex.getMessage());
        }
    }

}
