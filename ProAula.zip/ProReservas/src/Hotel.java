
import java.util.List;

public class Hotel {

    private int codigo;
    private String nombre;
    private String categoria;
    private String direccion;
    private String movil;

    private List<Habitacion> habitaciones;

    public Hotel() {
    }

    public Hotel(int codigo, String nombre, String categoria, String direccion, String movil, List<Habitacion> habitaciones) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.categoria = categoria;
        this.direccion = direccion;
        this.movil = movil;
        this.habitaciones = habitaciones;
    }

    public void setCodigo(int valor) {
        this.codigo = valor;
    }

    public void setNombre(String valor) {
        this.nombre = valor;
    }

    public void setCategorias(String valor) {
        this.categoria = valor;
    }

    public void setDireccion(String valor) {
        this.direccion = valor;
    }

    public void setMovil(String valor) {
        this.movil = valor;
    }

    public int getCodigo() {
        return this.codigo;
    }

    public String getNombre() {
        return this.nombre;
    }

    public String getCategorias() {
        return this.categoria;
    }

    public String getDireccion() {
        return this.direccion;
    }

    public String getMovil() {
        return this.movil;
    }

    public void setHabitaciones(List<Habitacion> valor) {
        this.habitaciones = valor;
    }

    public List<Habitacion> getHabitaciones() {
        return this.habitaciones;
    }

    public void MostrarHotel() {
        try {
            System.out.println("***Hotel***");
            System.out.println("Codigo: [" + this.codigo + "] "
                    + "Nombre: [" + this.nombre + "] "
                    + "Categoria: [" + this.categoria + "] "
                    + "Direccion: [" + this.direccion + "] "
                    + "Telefono: [" + this.movil + "]");

            System.out.println("");
            System.out.println("***Habitaciones***");

            for (Habitacion hab : this.habitaciones) {
                hab.MostrarHabitacion();
            }

        } catch (Exception ex) {
            System.out.println("ha ocurrido un error: " + ex.getMessage());
        }
    }
}
